<template>
    <div>
<center class="mt-5">        
        <h1 style="margin-bottom:290px">Coming Soon</h1>
</center>
    </div>
</template>

