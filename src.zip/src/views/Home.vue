<template>
  <div class="home" style="padding: 40px;">
  <div class="modal fade" id="modalAuction"  aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div style="width:400px" class="modal-dialog modal-dialog modal-dialog-centered" >
    <div class="modal-content border-0" style="border-radius:16px">
      <div class="modal-header modal-header-wallet">
        <button type="button" class="btn-close btn-close-white fs-6 close-style" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body mt-2">
      <div class="px-4 pb-2">
        <h4 style="border-bottom: 3px solid #ff3465;height:110px;">Please select the type of auction you want to create in Token Sale</h4>
        <select class="form-select mt-4">
  <option hidden selected>Type of</option>
  <option value="1">One</option>
  <option value="2">Two</option>
  <option value="3">Three</option>
</select>
      </div>
      <div class="modal-footer mt-2 justify-content-between border-0 px-4">
        <button type="button" style="width:150px" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" style="background: #ff3465;color:white;width:150px" class="btn">Confirm</button>
      </div>
      </div>
    </div>
  </div>
</div>
  <h1 style="font-weight:bold">Polkadot Tokens</h1>
  <hr>
  <div class="row">
  <div class="col-sm-3">
  <div class="input-group rounded" >
  <input type="search" class="form-control border-0"  placeholder="Search Token" aria-label="Search"
    aria-describedby="search-addon" />
  <span class="input-group-text border-0" id="search-addon">
    <i class="fas fa-search" style="color:#ff3465;"></i>
  </span>
</div>
 </div>
<div class="col-1" style="border-right:1px solid #ff9ab2;text-align:center">
        <a style="color:#ff3465;" class="nav-item nav-link ">Hot</a> 
  </div>
<div class="col-sm-1" style="border-right:1px solid #ff9ab2;text-align:center">
        <a style="color:#ff3465;float:left" class="nav-item nav-link ">Latest</a>
  </div>
<div class="col-1">
        <a style="color:#ff3465;float:left" class="nav-item nav-link ">End</a> 
  </div>
<div class="col"><button class="btn btn-dark" style="float:right;border-radius:20px"
 data-bs-toggle="modal" data-bs-target="#modalAuction">Create Auction</button> </div>
  </div>
   <hr>
   <div class="row" style="grid-row-gap: 30px;">
  <div class="col-sm center-m" style="width: 16.3rem;">
    <div class="card card-background" style=" border-radius: 25px;border-color:#ff3465;">
      <div class="card-body">
        <h5 class="card-title"><img src="../assets/Polkadot.png" style="width:40px;height:40px;">Polkadot</h5>  
        <hr>
<div style="font-size:16px;line-height: 0.7;">
        <p>Address<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Pair<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Swap Ratio<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Price<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Participants<span class="col sub-text" style="float:right;">0x2147912</span></p>
</div>
<div class="d-grid gap-2">
<button class="btn btn-dark">Detail</button>
</div>
      </div>
    </div>
  </div>
  
   <div class="col-sm center-m" style="width: 16.3rem;">
    <div class="card card-background" style=" border-radius: 25px;border-color:#ff3465;">
      <div class="card-body">
        <h5 class="card-title"><img src="../assets/Polkadot.png" style="width:40px;height:40px;">Polkadot</h5>  
        <hr>
<div style="font-size:16px;line-height: 0.7;">
        <p>Address<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Pair<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Swap Ratio<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Price<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Participants<span class="col sub-text" style="float:right;">0x2147912</span></p>
</div>
<div class="d-grid gap-2">
<button class="btn btn-dark">Detail</button>
</div>
      </div>
    </div>
  </div>

   <div class="col-sm center-m" style="width: 16.3rem;">
    <div class="card card-background" style=" border-radius: 25px;border-color:#ff3465;">
      <div class="card-body">
        <h5 class="card-title"><img src="../assets/Polkadot.png" style="width:40px;height:40px;">Polkadot</h5>  
        <hr>
<div style="font-size:16px;line-height: 0.7;">
        <p>Address<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Pair<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Swap Ratio<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Price<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Participants<span class="col sub-text" style="float:right;">0x2147912</span></p>
</div>
<div class="d-grid gap-2">
<button class="btn btn-dark">Detail</button>
</div>
      </div>
    </div>
  </div>

   <div class="col-sm center-m" style="width: 16.3rem;">
    <div class="card card-background" style=" border-radius: 25px;border-color:#ff3465;">
      <div class="card-body">
        <h5 class="card-title"><img src="../assets/Polkadot.png" style="width:40px;height:40px;">Polkadot</h5>  
        <hr>
<div style="font-size:16px;line-height: 0.7;">
        <p>Address<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Pair<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Swap Ratio<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Price<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Participants<span class="col sub-text" style="float:right;">0x2147912</span></p>
</div>
<div class="d-grid gap-2">
<button class="btn btn-dark">Detail</button>
</div>
      </div>
    </div>
  </div>

   <div class="col-sm center-m" style="width: 16.3rem;">
    <div class="card card-background" style=" border-radius: 25px;border-color:#ff3465;">
      <div class="card-body">
        <h5 class="card-title"><img src="../assets/Polkadot.png" style="width:40px;height:40px;">Polkadot</h5>  
        <hr>
<div style="font-size:16px;line-height: 0.7;">
        <p>Address<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Pair<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Swap Ratio<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Price<span class="col sub-text" style="float:right;">0x2147912</span></p>
        <p>Participants<span class="col sub-text" style="float:right;">0x2147912</span></p>
</div>
<div class="d-grid gap-2">
<button class="btn btn-dark">Detail</button>
</div>
      </div>
    </div>
  </div>

</div>
</div>

</template>
<style scoped>
.sub-text{
font-weight: bold;

}
.form-control:focus{
    outline: 0 !important;
    border-color: initial;
    box-shadow: none;
}
select{
  border:none;
  border-radius: 0;
  border-bottom: 1px solid;
  border-color:#f07390;
}
.form-select:focus{
  outline: 0 !important;
  border-color: #ff3465;
  box-shadow: none;
}
option{
 border-radius:70px;
}
.status-token{
padding-left:5px;
padding-right:10px;
font-size: 16px;
}
.card-background{
 color: white;
   text-shadow: 2px 2px 8px  #000000;
background-image:url('../assets/card-back.png');
 box-shadow:inset 0 0 0 2000px rgba(255, 255, 255, 0.2);
}
@media (max-width: 768px) { 
 .center-m{
  margin: auto;
}
  }

</style>
<script>
// @ is an alias to /src

</script>
